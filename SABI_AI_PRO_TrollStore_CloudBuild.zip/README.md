# SABI AI PRO — iOS project

SwiftUI starter project for iPhone. UI language is Albanian; the assistant responds in the user's language.

## Included
- Black + green premium chat UI
- Chat history saved locally
- API settings (key, endpoint, model)
- OpenAI-compatible Chat Completions API integration
- New chat, loading state, and API error messages

## Requirements
- macOS with Xcode 16 or newer
- iOS 17 deployment target
- An API key from an AI API provider that supports the OpenAI Chat Completions request format

## Open and build
1. Open `SABI_AI_PRO.xcodeproj` in Xcode.
2. Select the `SABI_AI_PRO` target and a valid signing Team.
3. Set a unique Bundle Identifier if needed.
4. Connect an iPhone, select it as the run destination, then press Run.
5. In the app, open Settings and enter your API key. The default endpoint/model are editable.

## Create an IPA
In Xcode, choose **Product → Archive**. In Organizer choose **Distribute App** and follow the signing/distribution flow. A valid Apple signing identity / provisioning profile is required.

## Important security note
This starter stores the API key in local app preferences for ease of testing. For a public production app, do not ship a shared API key inside the IPA. Put the provider key on your own backend and have the app call your authenticated backend instead. API usage may incur charges.

## Current limitations
- This is a complete starter source project, not a compiled/signed IPA.
- Image upload, voice mode, push notifications, and subscriptions are not implemented in this first version.
- The app requires an internet connection and a compatible API provider.


## Build IPA in the cloud for TrollStore (no Mac needed by you)

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build SABI AI PRO IPA for TrollStore** and press **Run workflow**.
4. When the workflow finishes, open its run and download the `SABI_AI_PRO_TrollStore` artifact.
5. Extract the downloaded artifact ZIP in Files. It contains `SABI_AI_PRO_TrollStore.ipa`.
6. Open the IPA using TrollStore (Share → TrollStore, or open it from Files if TrollStore is offered).

The workflow builds on a GitHub-hosted macOS runner and packages an unsigned app bundle. This project targets iOS 16.0+.

The workflow creates an unsigned IPA for TrollStore, not an App Store distribution build. The API key is entered in app Settings and stored locally for this prototype. For a public release, use a secure backend rather than embedding a shared API key.
