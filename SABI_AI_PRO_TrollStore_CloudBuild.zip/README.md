# SABI AI PRO BASIC — iOS 16+ / TrollStore

Premium black + green SwiftUI app with:
- AI chat through a Cloudflare Worker backend
- AI image generation through the same backend
- Voice dictation using Apple Speech and spoken assistant replies
- Admin backend health/model dashboard
- Albanian and English interface
- No provider API key stored in the iPhone app

## 1. Deploy the backend (Cloudflare Workers)

1. Create a Cloudflare Worker and deploy `worker.js` (or use Wrangler with `wrangler.toml`).
2. Add Worker secrets:
   - `OPENAI_API_KEY` = your OpenAI API key
   - `APP_TOKEN` = a long random app-access token (enter this in app Settings)
   - `ADMIN_TOKEN` = a separate long random admin password
3. Set optional Worker variables `CHAT_MODEL` and `IMAGE_MODEL` if desired. Defaults are `gpt-4.1-mini` and `gpt-image-1`.
4. Confirm `https://YOUR-WORKER.workers.dev/health` returns `{"ok":true,...}`.
5. In the app Settings, enter the Worker base URL, App access token, and optional Admin token. The OpenAI API key stays on the server.

OpenAI API use is billed according to the account's API pricing. Image generation may cost more than chat.

## 2. Build IPA on GitHub Actions

1. Upload the contents of this updated ZIP to your GitHub repository, replacing the old project ZIP and workflow. Keep the ZIP filename exactly `SABI_AI_PRO_TrollStore_CloudBuild.zip`.
2. Keep `.github/workflows/build-ipa.yml` in the repository.
3. Open Actions → Build SABI AI PRO IPA → Run workflow.
4. Download artifact `SABI-AI-PRO-IPA`, extract it, and install `SABI_AI_PRO_TrollStore.ipa` with TrollStore.

The workflow verifies that `CFBundleExecutable` points to a real Mach-O executable before packaging, to avoid the previous TrollStore “Unable to locate main binary” error.

## Notes
- This environment cannot sign or install an IPA. GitHub's macOS runner performs the Xcode build.
- Voice recognition uses Apple's on-device/system speech services and requires microphone + speech permissions.
- The admin screen is a simple protected backend status/model check, not a full user analytics console.
- The app-access token is a shared client credential and can be extracted from a modified app; it is not a substitute for user authentication. For public distribution, add Cloudflare rate limiting, per-user auth, quotas, and abuse monitoring.
