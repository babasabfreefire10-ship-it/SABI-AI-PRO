import SwiftUI
import UIKit

struct ImageGeneratorView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var prompt = ""
    private let green = Color(red: 0, green: 1, blue: 0.48)
    var body: some View {
        NavigationStack {
            ZStack { Color(red: 0.025, green: 0.035, blue: 0.03).ignoresSafeArea()
                ScrollView { VStack(alignment: .leading, spacing: 16) {
                    Text(store.language == "sq" ? "KRIJO ME AI" : "CREATE WITH AI").font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.white)
                    TextField(store.language == "sq" ? "Përshkruaj imazhin që dëshiron..." : "Describe the image you want...", text: $prompt, axis: .vertical).lineLimit(3...6).padding(14).background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14)).foregroundStyle(.white)
                    Button { Task { await store.generateImage(prompt: prompt) } } label: { HStack { if store.isGeneratingImage { ProgressView().tint(.black) } else { Image(systemName: "sparkles") }; Text(store.language == "sq" ? "Gjenero imazhin" : "Generate image") }.fontWeight(.bold).foregroundStyle(.black).frame(maxWidth: .infinity).padding(15).background(green, in: RoundedRectangle(cornerRadius: 14)) }.disabled(prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.isGeneratingImage)
                    if let data = store.generatedImage, let image = UIImage(data: data) { Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 16)) }
                    Text(store.language == "sq" ? "Gjenerimi kërkon backend të konfiguruar dhe mund të ketë kosto API." : "Image generation requires a configured backend and may incur API costs.").font(.caption).foregroundStyle(.gray)
                }.padding(20) }
            }.navigationTitle("Image Generator").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Close") { dismiss() }.foregroundStyle(green) } }
        }.preferredColorScheme(.dark)
    }
}
