import Foundation
import Speech
import AVFoundation

@MainActor
final class VoiceManager: ObservableObject {
    @Published var isRecording = false
    @Published var transcript = ""
    @Published var error: String?
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var recognizer: SFSpeechRecognizer?
    private let synthesizer = AVSpeechSynthesizer()

    func start(locale: String) {
        transcript = ""; error = nil
        SFSpeechRecognizer.requestAuthorization { [weak self] auth in
            Task { @MainActor in
                guard auth == .authorized else { self?.error = "Speech recognition permission is required."; return }
                self?.begin(locale: locale)
            }
        }
    }
    private func begin(locale: String) {
        stop()
        recognizer = SFSpeechRecognizer(locale: Locale(identifier: locale == "sq" ? "sq-AL" : "en-US")) ?? SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        guard let recognizer, recognizer.isAvailable else { error = "Speech recognition is unavailable."; return }
        let audio = AVAudioSession.sharedInstance()
        do {
            try audio.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audio.setActive(true, options: .notifyOthersOnDeactivation)
            request = SFSpeechAudioBufferRecognitionRequest()
            guard let request else { return }
            request.shouldReportPartialResults = true
            let input = engine.inputNode
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: input.outputFormat(forBus: 0)) { buffer, _ in request.append(buffer) }
            engine.prepare(); try engine.start(); isRecording = true
            task = recognizer.recognitionTask(with: request) { [weak self] result, err in
                Task { @MainActor in
                    if let result { self?.transcript = result.bestTranscription.formattedString }
                    if err != nil { self?.stop() }
                }
            }
        } catch { self.error = error.localizedDescription; stop() }
    }
    func stop() {
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio(); task?.cancel(); request = nil; task = nil; isRecording = false
        try? AVAudioSession.sharedInstance().setActive(false)
    }
    func speak(_ text: String, language: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: language == "sq" ? "sq-AL" : "en-US")
        utterance.rate = 0.48
        synthesizer.speak(utterance)
    }
}
