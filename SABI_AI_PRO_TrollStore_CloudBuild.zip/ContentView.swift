import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: ChatStore
    @StateObject private var voice = VoiceManager()
    @State private var input = ""
    @State private var showSettings = false
    @State private var showImages = false
    @State private var showAdmin = false
    @FocusState private var inputFocused: Bool
    private let green = Color(red: 0, green: 1, blue: 0.48)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.025, green: 0.035, blue: 0.03).ignoresSafeArea()
                VStack(spacing: 0) {
                    header
                    if store.messages.isEmpty { welcome } else { chatList }
                    voicePreview
                    composer
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) { SettingsView().environmentObject(store) }
            .sheet(isPresented: $showImages) { ImageGeneratorView().environmentObject(store) }
            .sheet(isPresented: $showAdmin) { AdminDashboardView().environmentObject(store) }
            .alert("SABI AI PRO", isPresented: Binding(get: { store.errorMessage != nil || voice.error != nil }, set: { if !$0 { store.errorMessage = nil; voice.error = nil } })) {
                Button("OK", role: .cancel) { store.errorMessage = nil; voice.error = nil }
            } message: { Text(store.errorMessage ?? voice.error ?? "") }
        }.preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(spacing: 10) {
            Text("S").font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.black)
                .frame(width: 42, height: 42).background(green, in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 2) {
                Text("SABI AI PRO").font(.system(size: 17, weight: .heavy, design: .rounded)).tracking(1)
                HStack(spacing: 5) { Circle().fill(store.isConfigured ? green : .orange).frame(width: 6, height: 6); Text(store.isConfigured ? "BACKEND READY" : "SETUP REQUIRED").font(.system(size: 9, weight: .bold)).tracking(1).foregroundStyle(.gray) }
            }
            Spacer()
            iconButton("photo.artframe", color: green) { showImages = true }
            iconButton("chart.bar.xaxis", color: .white) { showAdmin = true }
            iconButton("slider.horizontal.3", color: green) { showSettings = true }
        }.padding(.horizontal, 14).padding(.vertical, 12).overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }
    private func iconButton(_ name: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) { Image(systemName: name).font(.system(size: 15, weight: .semibold)).foregroundStyle(color).frame(width: 37, height: 39).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 11)) }
    }
    private var welcome: some View {
        ScrollView { VStack(alignment: .leading, spacing: 20) {
            Spacer(minLength: 30)
            Text("THINK BIGGER.\nBUILD WITH AI.").font(.system(size: 34, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(store.language == "sq" ? "Çfarë do të krijojmë sot?" : "What shall we create today?").font(.system(size: 16, weight: .medium)).foregroundStyle(.white.opacity(0.6))
            VStack(spacing: 10) {
                suggestion(store.language == "sq" ? "Më ndihmo me një ide biznesi" : "Help me with a business idea", icon: "lightbulb")
                suggestion(store.language == "sq" ? "Shpjego diçka thjesht" : "Explain something simply", icon: "sparkles")
                suggestion(store.language == "sq" ? "Shkruaj një tekst profesional" : "Write a professional message", icon: "pencil.line")
            }
            Text("AI Chat • Image Generator • Voice AI").font(.system(size: 11, weight: .bold)).foregroundStyle(green).padding(.top, 8)
        }.padding(22).frame(maxWidth: .infinity, minHeight: 400, alignment: .topLeading) }
    }
    private func suggestion(_ title: String, icon: String) -> some View {
        Button { input = title; Task { await sendMessage() } } label: {
            HStack(spacing: 12) { Image(systemName: icon).foregroundStyle(green).frame(width: 24); Text(title).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white); Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.gray) }
                .padding(15).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15)).overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.white.opacity(0.07)))
        }.buttonStyle(.plain)
    }
    private var chatList: some View {
        ScrollViewReader { proxy in ScrollView {
            LazyVStack(spacing: 17) {
                ForEach(store.messages) { message in
                    HStack(alignment: .top, spacing: 9) {
                        if message.role == .assistant { Text("S").font(.system(size: 13, weight: .black)).foregroundStyle(.black).frame(width: 27, height: 27).background(green, in: RoundedRectangle(cornerRadius: 9)) } else { Spacer(minLength: 35) }
                        Text(message.text).font(.system(size: 14)).foregroundStyle(.white).padding(13).background(message.role == .user ? Color(red: 0.04, green: 0.23, blue: 0.13) : Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 16))
                        if message.role == .user { Text("YOU").font(.system(size: 9, weight: .black)).foregroundStyle(green).padding(.top, 8) } else { Button { voice.speak(message.text, language: store.language) } label: { Image(systemName: "speaker.wave.2").foregroundStyle(green) } }
                        if message.role == .assistant { Spacer(minLength: 8) }
                    }.padding(.horizontal, 15).id(message.id)
                }
                if store.isLoading { HStack { ProgressView().tint(green); Text("SABI po mendon...").font(.system(size: 12)).foregroundStyle(.gray); Spacer() }.padding(.horizontal, 20) }
            }.padding(.vertical, 20)
        }.onChange(of: store.messages.count) { _ in if let last = store.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } } } }
    }
    private var voicePreview: some View {
        Group { if voice.isRecording || !voice.transcript.isEmpty {
            HStack(spacing: 8) { Image(systemName: "waveform").foregroundStyle(green); Text(voice.transcript.isEmpty ? "Listening…" : voice.transcript).font(.system(size: 12)).foregroundStyle(.white).lineLimit(2); Spacer(); Button("Use") { input = voice.transcript; voice.stop() }.foregroundStyle(green); Button { voice.stop() } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.gray) } }.padding(.horizontal, 16).padding(.vertical, 8)
        } }
    }
    private var composer: some View {
        HStack(alignment: .bottom, spacing: 8) {
            Button { if voice.isRecording { voice.stop() } else { voice.start(locale: store.language) } } label: { Image(systemName: voice.isRecording ? "stop.circle.fill" : "mic.fill").font(.system(size: 19)).foregroundStyle(green).frame(width: 42, height: 46).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14)) }
            TextField(store.language == "sq" ? "Shkruaj mesazhin..." : "Type a message...", text: $input, axis: .vertical).lineLimit(1...5).focused($inputFocused).font(.system(size: 15)).foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 13).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 17)).submitLabel(.send).onSubmit { Task { await sendMessage() } }
            Button { Task { await sendMessage() } } label: { Image(systemName: "arrow.up").font(.system(size: 17, weight: .bold)).foregroundStyle(.black).frame(width: 46, height: 46).background(green, in: RoundedRectangle(cornerRadius: 15)) }.disabled(store.isLoading || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty).opacity(store.isLoading || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.45 : 1)
        }.padding(.horizontal, 12).padding(.top, 10).padding(.bottom, 9).background(Color.black.opacity(0.35)).overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }
    private func sendMessage() async { let text = input; input = ""; inputFocused = false; await store.send(text) }
}
