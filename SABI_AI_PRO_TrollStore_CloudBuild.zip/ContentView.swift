import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: ChatStore
    @State private var input = ""
    @State private var showSettings = false
    @FocusState private var inputFocused: Bool

    private let green = Color(red: 0.0, green: 1.0, blue: 0.48)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.025, green: 0.035, blue: 0.03).ignoresSafeArea()
                VStack(spacing: 0) {
                    header
                    if store.messages.isEmpty {
                        welcome
                    } else {
                        chatList
                    }
                    composer
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView().environmentObject(store)
            }
            .alert("SABI AI PRO", isPresented: Binding(
                get: { store.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil } }
            )) {
                Button("Në rregull", role: .cancel) { store.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? "")
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 13).fill(green).frame(width: 42, height: 42)
                Text("S").font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.black)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("SABI AI PRO").font(.system(size: 17, weight: .heavy, design: .rounded)).tracking(1.1)
                HStack(spacing: 5) {
                    Circle().fill(green).frame(width: 6, height: 6)
                    Text("YOUR AI ASSISTANT").font(.system(size: 9, weight: .bold)).tracking(1.5).foregroundStyle(.gray)
                }
            }
            Spacer()
            Button { store.clearChat() } label: {
                Image(systemName: "square.and.pencil").font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white).frame(width: 40, height: 40)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
            }
            Button { showSettings = true } label: {
                Image(systemName: "slider.horizontal.3").font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(green).frame(width: 40, height: 40)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(.horizontal, 18).padding(.top, 12).padding(.bottom, 14)
        .overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }

    private var welcome: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Spacer(minLength: 34)
                Text("THINK BIGGER.\nBUILD WITH AI.")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Çfarë do të krijojmë sot?")
                    .font(.system(size: 16, weight: .medium)).foregroundStyle(.white.opacity(0.58))
                VStack(spacing: 10) {
                    suggestion("Shpjego diçka që nuk kuptoj", icon: "sparkles")
                    suggestion("Më ndihmo të shkruaj një tekst", icon: "pencil.line")
                    suggestion("Më jep ide për një biznes", icon: "lightbulb")
                    suggestion("Përkthe një tekst në anglisht", icon: "globe")
                }
                HStack(spacing: 7) {
                    Image(systemName: "lock.shield").foregroundStyle(green)
                    Text("Bisedat ruhen në këtë pajisje.")
                        .font(.system(size: 11, weight: .medium)).foregroundStyle(.gray)
                }.padding(.top, 6)
            }
            .padding(22).frame(maxWidth: .infinity, minHeight: 400, alignment: .topLeading)
        }
    }

    private func suggestion(_ title: String, icon: String) -> some View {
        Button {
            input = title
            Task { await sendMessage() }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon).foregroundStyle(green).frame(width: 24)
                Text(title).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                Spacer()
                Image(systemName: "arrow.up.right").font(.system(size: 11, weight: .bold)).foregroundStyle(.gray)
            }
            .padding(15).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.white.opacity(0.07), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var chatList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 17) {
                    ForEach(store.messages) { message in
                        MessageBubble(message: message, green: green).id(message.id)
                    }
                    if store.isLoading {
                        HStack(spacing: 9) {
                            ProgressView().tint(green)
                            Text("SABI po mendon...").font(.system(size: 12, weight: .medium)).foregroundStyle(.gray)
                            Spacer()
                        }.padding(.horizontal, 20)
                    }
                }.padding(.vertical, 20)
            }
            .onChange(of: store.messages.count) { _ in
                if let last = store.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
            }
        }
    }

    private var composer: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Shkruaj mesazhin...", text: $input, axis: .vertical)
                .lineLimit(1...5).focused($inputFocused)
                .font(.system(size: 15)).foregroundStyle(.white)
                .padding(.horizontal, 15).padding(.vertical, 13)
                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
                .submitLabel(.send)
                .onSubmit { Task { await sendMessage() } }
            Button { Task { await sendMessage() } } label: {
                Image(systemName: "arrow.up").font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.black).frame(width: 46, height: 46)
                    .background(green, in: RoundedRectangle(cornerRadius: 15))
            }.disabled(store.isLoading || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(store.isLoading || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.45 : 1)
        }
        .padding(.horizontal, 15).padding(.top, 12).padding(.bottom, 10)
        .background(Color.black.opacity(0.35))
        .overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }

    private func sendMessage() async {
        let text = input
        input = ""
        inputFocused = false
        await store.send(text)
    }
}

struct MessageBubble: View {
    let message: ChatMessage
    let green: Color

    var body: some View {
        HStack(alignment: .top, spacing: 9) {
            if message.role == .assistant {
                Text("S").font(.system(size: 13, weight: .black)).foregroundStyle(.black)
                    .frame(width: 27, height: 27).background(green, in: RoundedRectangle(cornerRadius: 9))
            } else { Spacer(minLength: 35) }
            Text(message.text)
                .font(.system(size: 14)).foregroundStyle(.white)
                .padding(13)
                .background(message.role == .user ? Color(red: 0.04, green: 0.23, blue: 0.13) : Color.white.opacity(0.065),
                            in: RoundedRectangle(cornerRadius: 16))
            if message.role == .user {
                Text("YOU").font(.system(size: 9, weight: .black)).foregroundStyle(green).padding(.top, 8)
            } else { Spacer(minLength: 8) }
        }.padding(.horizontal, 15)
    }
}
