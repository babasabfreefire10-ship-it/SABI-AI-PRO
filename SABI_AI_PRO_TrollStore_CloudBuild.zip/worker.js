const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Admin-Token",
  "Content-Type": "application/json; charset=utf-8"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: cors });

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    if (url.pathname === "/health") return json({ ok: true, service: "SABI AI PRO backend" });

    if (url.pathname === "/admin/overview" && request.method === "GET") {
      if (!env.ADMIN_TOKEN || request.headers.get("X-Admin-Token") !== env.ADMIN_TOKEN) return json({ error: "Unauthorized" }, 401);
      return json({ ok: true, chatModel: env.CHAT_MODEL || "gpt-4.1-mini", imageModel: env.IMAGE_MODEL || "gpt-image-1" });
    }

    if (url.pathname === "/chat" && request.method === "POST") {
      if (!env.APP_TOKEN || request.headers.get("X-App-Token") !== env.APP_TOKEN) return json({ error: "Unauthorized app" }, 401);
      if (!env.OPENAI_API_KEY) return json({ error: "Backend missing OPENAI_API_KEY secret" }, 500);
      try {
        const body = await request.json();
        const history = Array.isArray(body.history) ? body.history.slice(-20) : [];
        const language = body.language === "en" ? "English" : "Albanian";
        const messages = [
          { role: "system", content: `You are SABI AI PRO, a helpful and safe assistant. Reply in ${language} unless the user asks otherwise. Be practical, clear, and concise.` },
          ...history.filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string").map(m => ({ role: m.role, content: m.content }))
        ];
        if (!history.length || history[history.length - 1]?.content !== body.message) messages.push({ role: "user", content: String(body.message || "") });
        const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: env.CHAT_MODEL || "gpt-4.1-mini", messages, temperature: 0.7 })
        });
        const result = await upstream.json();
        if (!upstream.ok) return json({ error: result.error?.message || "AI provider error" }, upstream.status);
        return json({ reply: result.choices?.[0]?.message?.content || "No response" });
      } catch (e) { return json({ error: e.message || "Chat request failed" }, 500); }
    }

    if (url.pathname === "/image" && request.method === "POST") {
      if (!env.APP_TOKEN || request.headers.get("X-App-Token") !== env.APP_TOKEN) return json({ error: "Unauthorized app" }, 401);
      if (!env.OPENAI_API_KEY) return json({ error: "Backend missing OPENAI_API_KEY secret" }, 500);
      try {
        const body = await request.json();
        const prompt = String(body.prompt || "").trim();
        if (!prompt) return json({ error: "Prompt is required" }, 400);
        const upstream = await fetch("https://api.openai.com/v1/images/generations", {
          method: "POST",
          headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: env.IMAGE_MODEL || "gpt-image-1", prompt, size: "1024x1024" })
        });
        const result = await upstream.json();
        if (!upstream.ok) return json({ error: result.error?.message || "Image provider error" }, upstream.status);
        const imageBase64 = result.data?.[0]?.b64_json;
        if (!imageBase64) return json({ error: "Image provider returned no base64 image" }, 502);
        return json({ imageBase64 });
      } catch (e) { return json({ error: e.message || "Image request failed" }, 500); }
    }
    return json({ error: "Not found" }, 404);
  }
};
