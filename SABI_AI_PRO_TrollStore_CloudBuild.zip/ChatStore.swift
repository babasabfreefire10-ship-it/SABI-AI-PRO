import Foundation
import SwiftUI

@MainActor
final class ChatStore: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var apiKey: String = UserDefaults.standard.string(forKey: "sabi_api_key") ?? "" {
        didSet { UserDefaults.standard.set(apiKey, forKey: "sabi_api_key") }
    }
    @Published var endpoint: String = UserDefaults.standard.string(forKey: "sabi_endpoint") ?? "https://api.openai.com/v1/chat/completions" {
        didSet { UserDefaults.standard.set(endpoint, forKey: "sabi_endpoint") }
    }
    @Published var model: String = UserDefaults.standard.string(forKey: "sabi_model") ?? "gpt-4.1-mini" {
        didSet { UserDefaults.standard.set(model, forKey: "sabi_model") }
    }

    private let historyKey = "sabi_chat_history"

    init() { loadHistory() }

    func send(_ text: String) async {
        let prompt = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return }
        guard !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            errorMessage = "Shto API key te Settings për të përdorur AI."
            return
        }
        guard let url = URL(string: endpoint), url.scheme == "https" else {
            errorMessage = "Adresa API nuk është e vlefshme. Përdor një URL HTTPS."
            return
        }

        messages.append(ChatMessage(role: .user, text: prompt))
        saveHistory()
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        let history = messages.suffix(20).map {
            ChatRequest.Message(role: $0.role.rawValue, content: $0.text)
        }
        let requestBody = ChatRequest(
            model: model,
            messages: [ChatRequest.Message(role: "system", content: "You are SABI AI PRO, a helpful multilingual assistant. Reply in the language used by the user. Be clear, safe, and practical.") ] + history,
            temperature: 0.7
        )

        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.timeoutInterval = 60
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
            request.httpBody = try JSONEncoder().encode(requestBody)

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw APIError.message("Përgjigje e pavlefshme nga serveri.")
            }
            guard (200...299).contains(http.statusCode) else {
                let detail = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
                throw APIError.message("Gabim API (\(http.statusCode)): \(String(detail.prefix(350)))")
            }
            let decoded = try JSONDecoder().decode(ChatResponse.self, from: data)
            let answer = decoded.choices.first?.message.content.trimmingCharacters(in: .whitespacesAndNewlines)
            guard let answer, !answer.isEmpty else { throw APIError.message("AI nuk ktheu tekst.") }
            messages.append(ChatMessage(role: .assistant, text: answer))
            saveHistory()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func clearChat() {
        messages = []
        saveHistory()
    }

    private func saveHistory() {
        if let data = try? JSONEncoder().encode(messages) {
            UserDefaults.standard.set(data, forKey: historyKey)
        }
    }

    private func loadHistory() {
        guard let data = UserDefaults.standard.data(forKey: historyKey),
              let saved = try? JSONDecoder().decode([ChatMessage].self, from: data) else { return }
        messages = saved
    }
}

private struct ChatResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable { let content: String }
        let message: Message
    }
    let choices: [Choice]
}

private enum APIError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let text) = self { return text }
        return "Ndodhi një gabim i panjohur."
    }
}
