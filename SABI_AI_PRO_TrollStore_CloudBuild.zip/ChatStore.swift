import Foundation
import SwiftUI

@MainActor
final class ChatStore: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var backendURL: String = UserDefaults.standard.string(forKey: "sabi_backend_url") ?? ""
    @Published var adminToken: String = UserDefaults.standard.string(forKey: "sabi_admin_token") ?? ""
    @Published var appToken: String = UserDefaults.standard.string(forKey: "sabi_app_token") ?? ""
    @Published var language: String = UserDefaults.standard.string(forKey: "sabi_language") ?? "sq"
    @Published var generatedImage: Data?
    @Published var isGeneratingImage = false
    @Published var adminStatus: String?

    private let historyKey = "sabi_chat_history"
    init() { loadHistory() }

    var isConfigured: Bool { URL(string: backendURL)?.scheme == "https" }

    func send(_ text: String) async {
        let prompt = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return }
        guard let url = routeURL("/chat") else { errorMessage = language == "sq" ? "Vendos adresën HTTPS të backend te Settings." : "Add your HTTPS backend URL in Settings."; return }
        messages.append(ChatMessage(role: .user, text: prompt)); saveHistory()
        isLoading = true; errorMessage = nil
        defer { isLoading = false }
        do {
            let history = messages.suffix(20).map { ["role": $0.role.rawValue, "content": $0.text] }
            let body: [String: Any] = ["message": prompt, "history": history, "language": language]
            var req = URLRequest(url: url); req.httpMethod = "POST"; req.timeoutInterval = 90
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.setValue(appToken, forHTTPHeaderField: "X-App-Token")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                throw AppError.message(String(data: data, encoding: .utf8) ?? "Backend request failed")
            }
            let decoded = try JSONDecoder().decode(ChatBackendResponse.self, from: data)
            messages.append(ChatMessage(role: .assistant, text: decoded.reply)); saveHistory()
        } catch { errorMessage = error.localizedDescription }
    }

    func generateImage(prompt: String) async {
        guard let url = routeURL("/image") else { errorMessage = language == "sq" ? "Vendos adresën HTTPS të backend te Settings." : "Add your HTTPS backend URL in Settings."; return }
        isGeneratingImage = true; generatedImage = nil; errorMessage = nil
        defer { isGeneratingImage = false }
        do {
            var req = URLRequest(url: url); req.httpMethod = "POST"; req.timeoutInterval = 180
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.setValue(appToken, forHTTPHeaderField: "X-App-Token")
            req.httpBody = try JSONSerialization.data(withJSONObject: ["prompt": prompt])
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                throw AppError.message(String(data: data, encoding: .utf8) ?? "Image request failed")
            }
            let result = try JSONDecoder().decode(ImageBackendResponse.self, from: data)
            guard let bytes = Data(base64Encoded: result.imageBase64) else { throw AppError.message("Image data was invalid.") }
            generatedImage = bytes
        } catch { errorMessage = error.localizedDescription }
    }

    func loadAdminStatus() async {
        guard let url = routeURL("/admin/overview") else { adminStatus = "Set backend URL in Settings."; return }
        var req = URLRequest(url: url); req.setValue(adminToken, forHTTPHeaderField: "X-Admin-Token")
        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                adminStatus = "Access denied or backend error."; return
            }
            let result = try JSONDecoder().decode(AdminBackendResponse.self, from: data)
            adminStatus = "Backend: online\nChat model: \(result.chatModel)\nImage model: \(result.imageModel)"
        } catch { adminStatus = error.localizedDescription }
    }

    func clearChat() { messages = []; saveHistory() }
    private func routeURL(_ path: String) -> URL? {
        let base = backendURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let root = URL(string: base), root.scheme == "https" else { return nil }
        return URL(string: path, relativeTo: root)?.absoluteURL
    }
    private func saveHistory() {
        if let data = try? JSONEncoder().encode(messages) { UserDefaults.standard.set(data, forKey: historyKey) }
    }
    private func loadHistory() {
        guard let data = UserDefaults.standard.data(forKey: historyKey), let saved = try? JSONDecoder().decode([ChatMessage].self, from: data) else { return }
        messages = saved
    }
}

private struct ChatBackendResponse: Decodable { let reply: String }
private struct ImageBackendResponse: Decodable { let imageBase64: String }
private struct AdminBackendResponse: Decodable { let chatModel: String; let imageModel: String }
private enum AppError: LocalizedError { case message(String); var errorDescription: String? { if case .message(let s) = self { return s }; return "Unknown error" } }
