import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var revealKey = false
    private let green = Color(red: 0.0, green: 1.0, blue: 0.48)

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Image(systemName: "key.fill").foregroundStyle(green)
                        Group {
                            if revealKey {
                                TextField("API key", text: $store.apiKey)
                            } else {
                                SecureField("API key", text: $store.apiKey)
                            }
                        }
                        Button { revealKey.toggle() } label: {
                            Image(systemName: revealKey ? "eye.slash" : "eye").foregroundStyle(.secondary)
                        }
                    }
                    Text("API key përdoret për të komunikuar me ofruesin e AI. Mos e ndaj me askënd.")
                        .font(.caption).foregroundStyle(.secondary)
                } header: { Text("LIDHJA AI") }

                Section("Modeli") {
                    TextField("Model", text: $store.model)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("API endpoint", text: $store.endpoint)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                }

                Section {
                    Label("Black + Green Premium", systemImage: "circle.lefthalf.filled").foregroundStyle(green)
                    Label("Historiku ruhet lokalisht", systemImage: "internaldrive")
                    Label("Kërkohet internet dhe API key", systemImage: "wifi")
                } header: { Text("SABI AI PRO") }

                Section {
                    Button("Mbyll cilësimet") { dismiss() }.foregroundStyle(green)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.025, green: 0.035, blue: 0.03))
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
    }
}
