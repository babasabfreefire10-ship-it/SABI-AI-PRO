import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.dismiss) private var dismiss
    private let green = Color(red: 0.0, green: 1.0, blue: 0.48)
    var body: some View {
        NavigationStack {
            Form {
                Section("BACKEND / SERVER") {
                    TextField("https://your-worker.workers.dev", text: $store.backendURL)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("App access token", text: $store.appToken)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Admin token (optional)", text: $store.adminToken)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("OpenAI API key ruhet në Cloudflare. Vendos URL-në dhe App access token-in që krijon ti.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("LANGUAGE / GJUHA") {
                    Picker("Language", selection: $store.language) {
                        Text("Shqip").tag("sq")
                        Text("English").tag("en")
                    }.pickerStyle(.segmented)
                }
                Section("SABI AI PRO") {
                    Label("Black + Green Premium", systemImage: "circle.lefthalf.filled").foregroundStyle(green)
                    Label("AI Chat + Image Generator", systemImage: "sparkles")
                    Label("Voice dictation + spoken replies", systemImage: "waveform")
                    Label("Backend-protected API", systemImage: "lock.shield")
                }
                Section { Button("Close / Mbyll") { dismiss() }.foregroundStyle(green) }
            }
            .scrollContentBackground(.hidden).background(Color(red: 0.025, green: 0.035, blue: 0.03))
            .navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .onChange(of: store.backendURL) { UserDefaults.standard.set($0, forKey: "sabi_backend_url") }
            .onChange(of: store.adminToken) { UserDefaults.standard.set($0, forKey: "sabi_admin_token") }
            .onChange(of: store.appToken) { UserDefaults.standard.set($0, forKey: "sabi_app_token") }
            .onChange(of: store.language) { UserDefaults.standard.set($0, forKey: "sabi_language") }
        }.preferredColorScheme(.dark)
    }
}
