import SwiftUI

struct AdminDashboardView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.dismiss) private var dismiss
    private let green = Color(red: 0, green: 1, blue: 0.48)
    var body: some View {
        NavigationStack {
            ZStack { Color(red: 0.025, green: 0.035, blue: 0.03).ignoresSafeArea()
                VStack(alignment: .leading, spacing: 18) {
                    Text("ADMIN DASHBOARD").font(.system(size: 25, weight: .black, design: .rounded)).foregroundStyle(.white)
                    Text("Kontrollo lidhjen me backend-in. Vendos Admin token te Settings.").font(.system(size: 13)).foregroundStyle(.gray)
                    Button { Task { await store.loadAdminStatus() } } label: { Label("Kontrollo serverin", systemImage: "arrow.clockwise").fontWeight(.bold).foregroundStyle(.black).frame(maxWidth: .infinity).padding(14).background(green, in: RoundedRectangle(cornerRadius: 13)) }
                    if let status = store.adminStatus { Text(status).font(.system(.body, design: .monospaced)).foregroundStyle(green).padding(15).frame(maxWidth: .infinity, alignment: .leading).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14)) }
                    Spacer()
                }.padding(20)
            }.navigationTitle("Admin").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Close") { dismiss() }.foregroundStyle(green) } }
        }.preferredColorScheme(.dark)
    }
}
